import 'package:flutter/material.dart';

void main() => runApp(const NeedUpApp());

class NeedUpApp extends StatelessWidget {
  const NeedUpApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'NeedUp',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue)),
    home: const LoginScreen(),
  );
}

class NeedRequest {
  final String category, details, location;
  String status;
  NeedRequest({required this.category, required this.details, required this.location, this.status = 'Pending'});
}

final List<NeedRequest> requests = [];

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final otp = TextEditingController();
  bool otpSent = false;
  @override void dispose() { phone.dispose(); otp.dispose(); super.dispose(); }
  void sendOtp() {
    if (phone.text.trim().length != 10) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('10 digit mobile number dalo.'))); return;
    }
    setState(() => otpSent = true);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo OTP sent. Real SMS OTP Firebase setup ke baad chalega.')));
  }
  void verifyOtp() {
    if (otp.text.trim().length != 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('6 digit OTP dalo.'))); return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.handshake, size: 76, color: Colors.blue),
      const SizedBox(height: 10), const Text('NeedUp', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
      const Text('Need hai? NeedUp karo.', style: TextStyle(color: Colors.black54)), const SizedBox(height: 38),
      TextField(controller: phone, keyboardType: TextInputType.phone, maxLength: 10, decoration: const InputDecoration(prefixText: '+91 ', labelText: 'Mobile Number', border: OutlineInputBorder())),
      if (otpSent) TextField(controller: otp, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(labelText: 'OTP', border: OutlineInputBorder())),
      const SizedBox(height: 12), SizedBox(width: double.infinity, height: 52, child: ElevatedButton(onPressed: otpSent ? verifyOtp : sendOtp, child: Text(otpSent ? 'VERIFY OTP' : 'SEND OTP'))),
      if (otpSent) TextButton(onPressed: sendOtp, child: const Text('Resend OTP')),
    ])),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomeScreen(), NearbyScreen(), PostNeedScreen(), MessagesScreen(), ProfileScreen()];
  @override Widget build(BuildContext context) => Scaffold(body: pages[index], bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), destinations: const [
    NavigationDestination(icon: Icon(Icons.home), label: 'Home'), NavigationDestination(icon: Icon(Icons.location_on), label: 'Nearby'),
    NavigationDestination(icon: Icon(Icons.add_circle), label: 'Post'), NavigationDestination(icon: Icon(Icons.chat), label: 'Messages'), NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
  ]));
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  static const categories = [
    ('Mujhe Help Chahiye', Icons.sos), ('Vehicle Help', Icons.directions_car), ('House / Property', Icons.home),
    ('Home Services', Icons.build), ('Buy / Sell', Icons.shopping_bag), ('Nearby Services', Icons.location_on),
  ];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: Colors.blue.shade900, foregroundColor: Colors.white, title: const Text('NeedUp', style: TextStyle(fontWeight: FontWeight.bold)), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))]),
    body: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.location_on, color: Colors.blue), SizedBox(width: 5), Text('Your Location', style: TextStyle(fontWeight: FontWeight.w600))]), const SizedBox(height: 14),
      Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Colors.blue.shade800, borderRadius: BorderRadius.circular(20)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Koi bhi zarurat ho,', style: TextStyle(color: Colors.white, fontSize: 18)), SizedBox(height: 5), Text('NeedUp karo!', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)), SizedBox(height: 6), Text('Need hai? NeedUp karo.', style: TextStyle(color: Colors.white70))])),
      const SizedBox(height: 22), const Text('Aapko kya chahiye?', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: categories.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.18), itemBuilder: (context, i) => InkWell(borderRadius: BorderRadius.circular(18), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PostNeedScreen())), child: Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(blurRadius: 7, offset: Offset(0,2), color: Colors.black12)]), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(categories[i].$2, size: 40, color: Colors.blue), const SizedBox(height: 8), Text(categories[i].$1, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600))])))),
      const SizedBox(height: 20), SizedBox(width: double.infinity, height: 56, child: ElevatedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PostNeedScreen())), icon: const Icon(Icons.campaign), label: const Text('POST YOUR NEED', style: TextStyle(fontWeight: FontWeight.bold)))),
    ])),
  );
}

class PostNeedScreen extends StatefulWidget { const PostNeedScreen({super.key}); @override State<PostNeedScreen> createState() => _PostNeedScreenState(); }
class _PostNeedScreenState extends State<PostNeedScreen> {
  String category = 'Mujhe Help Chahiye'; final details = TextEditingController(); final location = TextEditingController();
  @override void dispose() { details.dispose(); location.dispose(); super.dispose(); }
  void submit() {
    if (details.text.trim().isEmpty || location.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Details aur location bharni hai.'))); return; }
    requests.insert(0, NeedRequest(category: category, details: details.text.trim(), location: location.text.trim()));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('NeedUp: request posted!')));
    details.clear(); location.clear(); setState(() {});
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Post Your Need')), body: ListView(padding: const EdgeInsets.all(16), children: [
    DropdownButtonFormField<String>(initialValue: category, decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()), items: const ['Mujhe Help Chahiye','Vehicle Help','House / Property','Home Services','Buy / Sell','Nearby Services'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (v) => setState(() => category = v!)),
    const SizedBox(height: 16), TextField(controller: details, maxLines: 4, decoration: const InputDecoration(labelText: 'Aapko kya chahiye?', hintText: 'Example: Bike road par band ho gayi hai...', border: OutlineInputBorder())),
    const SizedBox(height: 16), TextField(controller: location, decoration: const InputDecoration(labelText: 'Location', hintText: 'Area / landmark', border: OutlineInputBorder(), prefixIcon: Icon(Icons.location_on))),
    const SizedBox(height: 20), SizedBox(height: 52, child: ElevatedButton.icon(onPressed: submit, icon: const Icon(Icons.send), label: const Text('POST NEED'))),
  ]));
}

class RequestsScreen extends StatefulWidget { const RequestsScreen({super.key}); @override State<RequestsScreen> createState() => _RequestsScreenState(); }
class _RequestsScreenState extends State<RequestsScreen> {
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('My Requests')), body: requests.isEmpty ? const Center(child: Text('Abhi koi request nahi hai.')) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: requests.length, itemBuilder: (_, i) { final r = requests[i]; return Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.campaign)), title: Text(r.category), subtitle: Text('${r.details}\n📍 ${r.location}'), isThreeLine: true, trailing: Text(r.status)); }));
}



class NearbyScreen extends StatelessWidget {
  const NearbyScreen({super.key});
  static const providers = [
    ('Raj Mechanic', 'Bike / Car Help', '1.2 km'),
    ('Aman Electrician', 'Home Services', '2.0 km'),
    ('Quick Puncture', 'Tyre / Puncture', '2.6 km'),
    ('City Plumber', 'Plumbing', '3.1 km'),
  ];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Nearby Help'), actions: [
      IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo location: real GPS next phase me connect hoga.'))), icon: const Icon(Icons.my_location))
    ]),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(16)), child: const Row(children: [
        Icon(Icons.location_on, color: Colors.blue, size: 30), SizedBox(width: 10), Expanded(child: Text('Aapke aas-paas available help yahan dikhegi.'))
      ])),
      const SizedBox(height: 18),
      const Text('Nearby Providers', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      ...providers.map((p) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: Text(p.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${p.$2}\n📍 ${p.$3} away'), isThreeLine: true,
        trailing: ElevatedButton(onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(
          title: Text('Request sent to ${p.$1}'), content: Text('${p.$2} ke liye help request demo mode me send ho gayi.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        )), child: const Text('Request')),
      ))),
      const SizedBox(height: 8),
      const Text('Safety: milne se pehle provider ki profile, rating aur verification check karo.', style: TextStyle(color: Colors.black54)),
    ]),
  );
}

class MessagesScreen extends StatelessWidget { const MessagesScreen({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Messages')), body: const Center(child: Text('Messages feature next phase me connect hoga.'))); }
class ProfileScreen extends StatelessWidget { const ProfileScreen({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Profile')), body: ListView(padding: const EdgeInsets.all(16), children: const [CircleAvatar(radius: 42, child: Icon(Icons.person, size: 45)), SizedBox(height: 16), Center(child: Text('NeedUp User', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))), SizedBox(height: 20), ListTile(leading: Icon(Icons.verified_user), title: Text('Verification'), subtitle: Text('Phone verification Firebase se connect hoga')), ListTile(leading: Icon(Icons.star), title: Text('Rating'), subtitle: Text('Abhi 0 ratings')), ListTile(leading: Icon(Icons.shield), title: Text('Safety & Report'), subtitle: Text('Report/block tools next phase me'))])); }
