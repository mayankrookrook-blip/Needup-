# NeedUp Flutter Starter v0.4

NeedUp local-help app prototype.

## v0.4 added
- Nearby Help screen
- Demo nearby providers with distance labels
- Request button and confirmation dialog
- Safety reminder
- Bottom navigation now includes Nearby

## Important
Location and requests are demo/local only. Real GPS, Firebase database, real SMS OTP, provider accounts, notifications and moderation need backend configuration in a later phase.

## Run
1. Install Flutter SDK.
2. Run `flutter pub get`.
3. Run `flutter run`.
